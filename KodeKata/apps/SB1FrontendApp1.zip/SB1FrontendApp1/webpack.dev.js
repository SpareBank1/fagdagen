const path = require('path');

module.exports = {
  entry: './src/frontend/main.js',
  output: {
    path: __dirname + "/public/bundles",
    filename: "bundle.js"
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: ['babel-loader']
      },
      {
        test: /\.(less|css)$/,
        use: [
          {
            loader: "style-loader",
            options: { sourceMap: true }
          },
          {
            loader: "css-loader",
            options: { sourceMap: true }
          },  
          {
            loader: "less-loader",
            options: { outputStyle: 'expanded', sourceMap: true, sourceMapContents: true }
          }
        ]
      }
    ]
  },
  resolve: {
    extensions: ['*', '.js', '.jsx']
  },
  plugins: [
  ]
};