import React from 'react';

class Root extends React.Component {
  render() {
    return (<div className="row">
      
      <div className="col">
        <div>
          <label className="ffe-form-label" htmlFor="input-01">Input</label>
          <input className="ffe-input-field" id="input-01"/>
        </div>
      </div>

      <div className="col" style={{ marginTop: "20px" }}>
        <button className="ffe-button ffe-button--action">
          <span className="ffe-button__label">Action button</span>
          <div aria-hidden="true" aria-label="Action button" className="ffe-button__spinner"></div>
        </button>
      </div>

    </div>);
  }
}

export default Root;
