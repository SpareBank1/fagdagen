const express    = require('express');
const app        = express();
    
Object.assign = require('object-assign');

const port = process.env.PORT || 8080;
const ip   = process.env.IP || '0.0.0.0';

app.get('/api', function (req, res) {
  res.send('Hei fra SpareBank1');
});

// Static content
app.use(express.static('public'))

// Error handling
app.use(function(err, req, res, next){
  console.error(err.stack);
  res.status(500).send('Nå skjedde det noe dumt');
});

app.listen(port, ip);
console.log('Server is running on http://%s:%s', ip, port);

module.exports = app ;
