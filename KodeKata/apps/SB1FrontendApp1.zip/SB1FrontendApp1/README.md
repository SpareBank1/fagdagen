# Demo frontend-app for SpareBank1

## Prerequisites
Prior to running this application you need to install:
 * Node.js

## Running the application
To start the application we need to run the following commands
 * ```npm install```
 * ```npm run build```
 * ```npm start```

Now the server is running on default port 8080. Open a browser and navigate to http://localhost:8080

## Developing frontend code
Open another terminal and code will be automatically reloaded
 * ```npm run dev```
